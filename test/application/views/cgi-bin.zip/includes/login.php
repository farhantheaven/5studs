


<div>
<form id="login">
<label for="username">Username</label><input type="text" name="username" class="placeholder" placeholder="username">
<label for="password">Password</label><input type="password" name="password" class="placeholder" placeholder="password">
<input type="submit" value="Log In">
</form>
</div>
