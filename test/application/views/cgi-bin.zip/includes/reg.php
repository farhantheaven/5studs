<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>PanunKart Login</title>
<link rel="stylesheet" type="text/css" href="sitecss.css" />
</head>
<body>

<div id="side">
<h3><span style="color:#EBEBEB;">PANUN</span>KART</h3><img scr="media/3.jpg">
<p>
By registering on PanunKart,you become eligible for enumerous services like sending of emails on new bookings.
Free account registration and you get valuable things.You only have to give yor email and password.If you want to ask us anything
we are available 24*7
By registering on PanunKart,you become eligible for enumerous services like sending of emails on new bookings.
Free account registration and you get valuable things.You only have to give yor email and password.If you want to ask us anything
we are available 24*7
By registering on PanunKart,you become eligible for enumerous services like sending of emails on new bookings.
Free account registration and you get valuable things.You only have to give yor email and password.If you want to ask us anything
we are available 24*7
By registering on PanunKart,you become eligible for enumerous services like sending of emails on new bookings.
Free account registration and you get valuable things.You only have to give yor email and password.If you want to ask us anything
we are available 24*7

</p>


</div>




<div id="reg">
<label  style="color:#ABDA0F;" text-align="center"   >PERSONAL DETAILS :</label></br>
<label >Name </label><input type="text" name="username" class="placeholder" placeholder="Full name"></br>
<label >Phone</label><input type="integer" name="password" class="placeholder" placeholder="Phone no"></br>
<label >Username </label><input type="text" name="password" class="placeholder" placeholder="Choose a username for you">

</div>

<div id="reg2">
<label style="color:#ABDA0F;">ACCOUNT DETAILS :</label></br>
<label >Email</label><input type="text" name="username" class="placeholder" placeholder="something@email.com"></br>
<label > Confirm Email </label><input type="text" name="password" class="placeholder" placeholder="Repeat your email"></br>
<label >Password </label><input type="password" name="password" class="placeholder" placeholder="Password"></br>
<label >Confirm Password</label><input type="password" name="password" class="placeholder" placeholder="Confirm Password"></br>

</div>

<div id="reg3">
	<label class="tandc" for="username" style="color:#ABDA0F;">TERMS AND CONDITIONS :</label></br>
 <p >
                    <input class="chk" type="checkbox" value=""/>
                    <label> I accept the <a href="#">Terms and Conditions</a></label>
                </p>
                <p >
                    <input class="chk"  type="checkbox" value=""/>
                    <label>I want to receive personalized offers by your site</label>
                </p>
                <p >
                    <input  class="chk" type="checkbox" value=""/>
                    <label>Allow partners to send me personalized offers and related services</label>
                </p>

<button id="regbutton">Register &raquo;</button>

</div>
<div id="reg4">
    <label>Already have an account <a href="#">Log In</a></label>

                                                     <label class="lbl2">   Have anything to say <a href="#">Let's know</a></label>


</div>


</body>
</html>