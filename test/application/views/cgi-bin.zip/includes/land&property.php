<div class="w3-padding-jumbo" id="bakki" >
<p class="w3-center">
we provide you best of india's lands and property.which makes you more confidencial and gives more happinies!!!!!!
</p>
</div> 
<div class="container-fluid">
<div class="row">
  <div  id="coulum1"  class="w3-card-4 col-md-4 col-sm-6 col-xs-8" >
   <img src ="media\1.jpg"   id="coulum2" class="image-responsive">
    <h3 class="w3-center">LAND</h3>
    <a href="#" ><p class="w3-center">Invest in land</p></a>
      </div> 
		 </div>
		 
		 <div class="container-fluid">
		 <div id="coulum11" class="w3-card-4 col-md-4 col-sm-6 col-xs-8" >
   <img src="media\2.jpg"  id="coulum2">
   <div class="w3-container">
    <h3 class="w3-center">PLOT</h3>
	<a href="#"><p class="w3-center">Invest in<br> peoperty</p></a>
  </div>
         </div>
		 </div>
  </div>