<div class="w3-center">
<p>  !!!!-----------------------------------------------------DEVELOPERS--------------------------------------------------!!!!
 <br>Farhan khan <br>
    Jai Sawlani <br>
	Dinesh raj <br>
	lalit verma <br>
	Nikhil cheeta <br>
	Deependra singh <br>
	Jitendra singh  <br>
	Faizan nabi <br>
	Asif <br>
	Mohsin <br>
	shubham <br>
	Rhytham chopra <br>
	arvind <br>
   Aiman <br>
   pooja sangra<br>
   mamta<br>
   Tushar gupta <br>
   Animesh
	</p>
</div>