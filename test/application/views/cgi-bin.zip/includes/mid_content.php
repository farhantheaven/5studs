
<h1 id="text">
<font color="lightslategrey">
<center>
<p>HOMES TO HAPPINESS</p></center>
</font>
<h3 id="text">
<center>There are so many companies out there,we value your choice.</center></h3>


<div class="container-fluid"   id="mid-content">
  <div class="col-md-4 col-sm-6" >
   <a href="#"><img src ="media/12.jpg" class="img-circle" alt="BUY" width="200" height="200"></a>
	  <p><a href="#"  target="_self">Buy</a></br>
	  We provide best property<br> options available.</br>
     The listings are provided after<br> ultra-level verifications.</p>
  </div>
  <div class="col-md-4 col-sm-6"  >
   <a href="#"> <img src="media/11.jpg" class="img-circle" alt="SELL" width="200" height="200"><div id="changehover"></div></a><a href="#"  target="_self">SELL</a></br>
      <p id="text1">Have something to sell?.</br>We provide you easy-selling <br>options at your comfort prices.</p>
        
  </div>
  <div class="col-md-4 col-sm-6"  >
    <a href="#"><img src="media/13.jpg" class="img-circle" alt="rent" width="200" height="200"></a>
      <p>HOME AWAY FROM HOME</p>
  </div>
</div>
