
<div class="Container-fluid">
<div class="w3-padding-2 w3-center" id="bakki" >
<h2>OUR RECENT LISTING</h2>
</div>
<div class="row" id="wrapper11">
  <div class="col-md-2 col-sm-6 col-xs-8">
   <a href="#"><img src ="media\21.jpg"  width="180" height="250"></a>
	  <p><center> LISTING 1 <br> this is 1BHK</center></p>
  </div>
  <div class="col-md-2 col-sm-6 col-xs-8 ">
   <a href="#"> <img src="media\22.jpg"  width="180" height="250" ></a>
   <P><center>LISTING 2 <br> this is 2BHK</center></P>
  </div>
  <div class="col-md-2 col-sm-6 col-xs-8">
    <a href="#"><img src="media\23.jpg"  width="180" height="250" ></a>
	<p><center>LISTING 3 <br> this is 3BHK</center></p>
  </div>
  <div class="col-md-2 col-sm-6 col-xs-8">
    <a href="#"><img src="media\24.jpg"  width="180" height="250" ></a>
	<p> <center>LISTING 4 <br> this is For rent</center> </p>
  </div>
  <div class="col-md-2 col-sm-6 col-xs-8">
    <a href="#"><img src="media\25.jpg"  width="180" height="250" ></a>
	<p> <center>LISTING 5 <br> homes on loan </center></p>
  </div>
</div>
</div>