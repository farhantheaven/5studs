<footer class="footer-distributed">

			<div class="footer-left"  style="margin-top:0px;" width="40%" valign="left"  align="left" >
 
				<h3>Panun<span>Kart</span></h3>

				<p class="footer-links">
					<a href="#">Home</a>
					·
					<a href="#">Blog</a>
					·
					<a href="#">Partners</a>
					·
					<a href="#">Achievements</a>
					
					
				</p>

				<p class="footer-company-name" align="bottom">
				copyright@panunkart.com
				
				</p>
			</div>

			<div class="footer-center" align="">

				<div>
				<table style="margin-top:0px;" width="100%" valign=""  align="">
  <tr>
  <td>
   <p style="color:white; font-size:15px;"  >HELP</p>
    </td>
  <td>
  <p style="color:white; font-size:15px;"  >REACH US</p>
  </td>
  <td>
   <p style="color:white; font-size:15px;"  >PANUNKART</p>
  </td>
   </tr>
  
  
      <tr>
  <td>
   <a href="#" style="color:white; font-size:10px;" target="_blank"  >FAQs</a>
  
  </td>
  <td>
  <a href="#"  style="color:white; font-size:10px;"   target="_blank" >Contact</a>
  </td>
  <td>
   <a href="#"   style=" color:white; font-size:10px;"  target="_blank" >Support Us</a>
  </td>
 
  </tr>
  
  
    <tr>
  <td>
   <a href="#" style="color:white; font-size:10px;" target="_blank"  >Site</a>
  
  </td>
  <td>
  <a href="#"  style="color:white; font-size:10px;"   target="_blank" >Partners</a>
  </td>
  <td>
   <a href="#"   style=" color:white; font-size:10px;"  target="_blank" >Suggestions</a>
  </td>
 
  </tr>
  
  <tr>

  <td>
   <a href="#" style="color:white; font-size:10px;" target="_blank"  >Sitemap</a>
  
  </td>
  <td>
  <a href="#"  style="color:white; font-size:10px;"   target="_blank" >Partners</a>
  </td>
  <td>
   <a href="#"   style=" color:white; font-size:10px;"  target="_blank" > Aboutus</a>
  </td>
  
  </tr>
  
  </table> 
  				</div>

				
			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About us</span>
					Panunkart is a real estate website providing homes to everyone.We are more concerned with customer needs.
				</p>
<div class="footer-icons" align="left">

					<a href="https://facebook.com/PanunKart"><img src="media\facebook_32.png"></a>
					<a href="https://twitter.com/"><img src="media\twitter_32.png"></a>
					<a href="https://linkedin.com"><img src="media\linkedin_32.png"></a>
					<a href="https://gmail.com"><img src="media\google_32.png"></a>
										
                    
				</div>

				

			</div>

		</footer>
</body> 
</html>