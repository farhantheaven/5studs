<div class="w3-padding-2 w3-center" id="bakki" >
<h2>OUR RECENT LISTING</h2>
</div>
<div class="row" style="padding:50px">
                <div class="col-md-12">
                    <div class="carousel carousel-showmanymoveone slide" id="carousel123">
                        <div class="carousel-inner">
                            <div class="item active col-xs-12 col-sm-6 col-md-3"><a href="#"><img src="media/1.jpg" class="img-responsive" id="imagesetting" ></a></div>
                            <div class="item col-xs-12 col-sm-6 col-md-3"><a href="#"><img src="media/2.jpg" class="img-responsive" id="imagesetting"></a></div>
                          
                            <div class="item col-xs-12 col-sm-6 col-md-3"><a href="#"><img src="media/3.jpg" class="img-responsive" id="imagesetting"></a></div>
                        </div>
                        <a class="left carousel-control" href="#carousel123" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
                        <a class="right carousel-control" href="#carousel123" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
                    </div>
                </div>
            </div>
		