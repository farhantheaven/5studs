<!-- ************************************ SEARCH TAB **************************************** -->

<div id="search_tab" class="container-fluid navbar navbar-inverse">
	
    <form>     

	<div class="btn-group col-md-2">	
	</div>	
	
        <!--Property Type button with dropdown menu-->
        <div class="btn-group col-md-2">
            <button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle navbar-btn">Property Type <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="#">Test 1</a></li>
                <li><a href="#">Test 2</a></li>
                <li><a href="#">Test 3</a></li>
            </ul>
        </div>
		
		<!--Budget button with dropdown menu-->
        <div class="btn-group col-md-2">
            <button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle navbar-btn">Budget <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="#">Test 1</a></li>
                <li><a href="#">Test 2</a></li>
                <li><a href="#">Test 3</a></li>
            </ul>
        </div>
		
		<!--Locality button with dropdown menu-->
        <div class="btn-group col-md-2">
            <button type="button" data-toggle="dropdown" class="btn btn-primary dropdown-toggle navbar-btn">Locality <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="#">Test 1</a></li>
                <li><a href="#">Test 2</a></li>
                <li><a href="#">Test 3</a></li>
            </ul>
        </div>
		
	<div class="btn-group col-md-2">
		<button type="button" class="btn btn-success navbar-btn">LOOK UP!</button>
	</div>
	
	<div class="btn-group col-md-2">	
	</div>
                
    </form>
</div>
