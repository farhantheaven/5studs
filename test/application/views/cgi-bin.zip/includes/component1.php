<div class="container-fluid" id="bakki12">
<h3 id="text">
<font color="lightslategrey">
<center>
<p>HOMES TO HAPPINESS</p></center>
 </h3></font>
<h3 id="text">
<center>There are so many companies out there,we value your choice.</center></h3>
<section class="main" style="padding:50px">
            
                <ul class="ch-grid">
                    <li>
                        <div class="ch-item ch-img-1 w3-card-16">
                            <div class="ch-info"><br><br><br>
                                <div class="tooltip-wrap">
                                <h1><a href="" class="grey">Buy</a></h1>
								<p>We provide best property<br> options available.</br>
     The listings are provided after<br> ultra-level verifications.</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="ch-item ch-img-2 w3-card-16">
                            <div class="ch-info"><br><br><br>
                            <div class="tooltip-wrap">
                                <h1><a href="" class="grey">Sell</a></h1>
								<p id="text1">Have something to sell?.</br>We provide you easy-selling <br>options at your comfort prices.</p>
                            </div>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="ch-item ch-img-3 w3-card-16">
                            <div class="ch-info"><br><br><br>
                            <div class="tooltip-wrap">
                                <h1><a href="" class="grey">Rent</a></h1>
								<p>HOME AWAY FROM HOME</p>
                            </div>
                        </div>
                        </div>
                    </li>
                </ul>
                
            </section>
</div>