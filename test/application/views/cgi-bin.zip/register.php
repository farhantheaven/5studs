<?php
include "includes/head.php";
include "includes/onlyheader.php";
include "includes/reg.php";





include "includes/footer.php";
?>
