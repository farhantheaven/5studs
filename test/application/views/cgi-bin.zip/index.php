<?php
include "includes/head.php";
include "includes/header.php";
include "includes/search_tab.php";
include "includes/component1.php";

include "includes/multislider.php";
include "includes/land&property.php";

include "includes/scriptlib.php";
include "includes/footer.php";
?>
